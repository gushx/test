import index from "./js/index";
import "./index.css";