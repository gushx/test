This is the repo for paper submission

```
frontend
- npm install
- npm run serve
```

```
backend
- python run-data-backend.py
```


Environment:
- Vue 3.6.3
- d3v5
- python 3.6
